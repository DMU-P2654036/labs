const path1 = document.getElementById("path1");
const path2 = document.getElementById("path2");
const story = document.querySelector(".story");

path1.addEventListener("click", () => {
  story.textContent =
    "You chose Path 1. You walk for hours and come across a river. Do you try to cross it or follow the riverbank?";
  path1.textContent = "Cross the river";
  path2.textContent = "Follow the riverbank";
});

path2.addEventListener("click", () => {
  story.textContent =
    "You chose Path 2. You walk for a while and come across a clearing with a cottage. Do you investigate or keep walking?";
  path1.textContent = "Investigate the cottage";
  path2.textContent = "Keep walking";
});

path1.addEventListener("click", () => {
  story.textContent =
    "You chose to cross the river. The water is icy cold and swift, but you manage to make it across. You come across a village and find your way back home.";
  path1.style.display = "none";
  path2.style.display = "none";
});

path2.addEventListener("click", () => {
  story.textContent =
    "You chose to follow the riverbank. You walk for miles and eventually find a boat. You sail down the river and come across a village. You find your way back home.";
  path1.style.display = "none";
  path2.style.display = "none";
});
